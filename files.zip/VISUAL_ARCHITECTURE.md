# 🎨 VISUAL SYSTEM ARCHITECTURE
*See The Big Picture at a Glance*

---

## 🏗️ COMPLETE SYSTEM OVERVIEW

```
┌───────────────────────────────────────────────────────────────┐
│                    SCRIBEMD PRO ECOSYSTEM                      │
└───────────────────────────────────────────────────────────────┘

┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   iOS App   │  │ Android App │  │   Web App   │  │   Admin     │
│ (Capacitor) │  │ (Capacitor) │  │   (React)   │  │  Dashboard  │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │                │
       └────────────────┴────────────────┴────────────────┘
                            │
                    ┌───────▼───────┐
                    │  Vercel Edge  │
                    │   (Frontend)  │
                    └───────┬───────┘
                            │
                    ┌───────▼───────┐
                    │   API Layer   │
                    │  (Serverless) │
                    └───────┬───────┘
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
   ┌───▼────┐        ┌──────▼──────┐      ┌─────▼─────┐
   │Supabase│        │  AI Services │      │   EHR     │
   │        │        │              │      │           │
   │• Auth  │        │• Deepgram   │      │• DrChrono │
   │• DB    │        │  (Speech)   │      │  (OAuth)  │
   │• Storage│       │              │      │           │
   │• RLS   │        │• Anthropic  │      │• Export   │
   │        │        │  (Claude)   │      │  Notes    │
   └────────┘        │  (SOAP)     │      └───────────┘
                     │              │
                     │• Stripe     │
                     │  (Billing)  │
                     └─────────────┘
```

---

## 👥 USER JOURNEY FLOW

```
┌─────────────────────────────────────────────────────────────┐
│               PROVIDER USING SCRIBEMD PRO                    │
└─────────────────────────────────────────────────────────────┘

1. LOGIN
   │
   ├─► Enter credentials
   ├─► Supabase Auth validates
   └─► JWT token issued
       │
       ▼
2. SELECT PATIENT
   │
   ├─► Search patient database
   ├─► View patient history
   └─► Start new encounter
       │
       ▼
3. ENCOUNTER
   │
   ├─► Say: "Hey ScribeMD, start encounter"
   ├─► Real-time transcription begins
   ├─► Live text appears on screen
   ├─► Clinical intelligence analyzes
   │   ├─► Red flag alerts
   │   ├─► Differential diagnosis
   │   └─► ICD-10 suggestions
   │
   ▼
4. SOAP GENERATION
   │
   ├─► Click "Generate SOAP"
   ├─► Claude AI processes transcript
   ├─► SOAP note appears (10 seconds)
   ├─► Edit/refine as needed
   └─► Approve final note
       │
       ▼
5. FINALIZE
   │
   ├─► Sign encounter
   ├─► Export options:
   │   ├─► DrChrono (auto-push)
   │   ├─► PDF download
   │   └─► Print
   └─► Complete! Next patient →
```

---

## 🔄 DATA FLOW ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                    REAL-TIME ENCOUNTER                       │
└─────────────────────────────────────────────────────────────┘

STEP 1: AUDIO CAPTURE
┌──────────────┐
│  Microphone  │
│   (Browser)  │
└──────┬───────┘
       │ Audio Stream
       ▼
┌──────────────┐
│   WebSocket  │
│  Connection  │
└──────┬───────┘
       │
       ▼

STEP 2: TRANSCRIPTION
┌──────────────┐
│  Deepgram    │
│   API        │
│              │
│ • Real-time  │
│ • 95%+ acc   │
└──────┬───────┘
       │ Text Stream
       ▼
┌──────────────┐
│   Frontend   │
│  (Display)   │
└──────┬───────┘
       │
       ▼

STEP 3: SOAP GENERATION
┌──────────────┐
│   Trigger    │
│  "Generate"  │
└──────┬───────┘
       │ Full Transcript
       ▼
┌──────────────┐
│  Claude API  │
│              │
│ • Context    │
│ • Clinical   │
│ • Structured │
└──────┬───────┘
       │ SOAP JSON
       ▼
┌──────────────┐
│  Supabase    │
│  (Store)     │
└──────┬───────┘
       │
       ▼

STEP 4: DISPLAY & EXPORT
┌──────────────┐
│   Frontend   │
│  (Render)    │
└──────┬───────┘
       │
       ├─► Edit/Review
       ├─► Sign
       ├─► Export PDF
       └─► Push to EHR
```

---

## 🗄️ DATABASE STRUCTURE

```
┌────────────────────────────────────────────────────────────┐
│                  SUPABASE DATABASE                          │
└────────────────────────────────────────────────────────────┘

practices (Tenants)
├── id (PK)
├── name
├── subscription_tier
└── stripe_customer_id
    │
    ├─► users (Many-to-One)
    │   ├── id (PK)
    │   ├── practice_id (FK)
    │   ├── email
    │   ├── role (admin, provider, ma)
    │   └── npi
    │
    ├─► patients (Many-to-One)
    │   ├── id (PK)
    │   ├── practice_id (FK)
    │   ├── first_name
    │   ├── last_name
    │   ├── date_of_birth
    │   └── mrn
    │
    └─► encounters (Many-to-One)
        ├── id (PK)
        ├── practice_id (FK)
        ├── patient_id (FK)
        ├── provider_id (FK)
        ├── raw_transcript (TEXT)
        ├── soap_note (JSONB)
        ├── icd10_codes (JSONB)
        ├── em_level
        └── created_at

audit_logs (HIPAA)
├── id (PK)
├── practice_id (FK)
├── user_id (FK)
├── action (view, create, update, delete)
├── resource_type
└── created_at
```

---

## 🔐 SECURITY LAYERS

```
┌────────────────────────────────────────────────────────────┐
│                    SECURITY STACK                           │
└────────────────────────────────────────────────────────────┘

LAYER 1: TRANSPORT
    ├─► TLS 1.3 (All Connections)
    ├─► HTTPS Only
    └─► Certificate Pinning (Mobile)

LAYER 2: AUTHENTICATION
    ├─► JWT Tokens (1hr expiry)
    ├─► Refresh Tokens
    ├─► MFA Optional
    └─► IP Whitelisting (Admin)

LAYER 3: AUTHORIZATION
    ├─► Role-Based Access (RBAC)
    ├─► Row-Level Security (RLS)
    ├─► Practice Isolation
    └─► API Rate Limiting

LAYER 4: DATA
    ├─► Encryption at Rest (AES-256)
    ├─► Field-Level Encryption
    ├─► Secure File Storage
    └─► Audit Logging

LAYER 5: COMPLIANCE
    ├─► HIPAA BAAs Signed
    ├─► PHI Access Logs
    ├─► 7-Year Retention
    └─► Incident Response Plan
```

---

## 📱 MOBILE APP ARCHITECTURE

```
┌────────────────────────────────────────────────────────────┐
│                CAPACITOR MOBILE APPS                        │
└────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                    React Web App                         │
│                  (Single Codebase)                       │
└──────────────────────┬──────────────────────────────────┘
                       │
        ┌──────────────┴──────────────┐
        │                             │
┌───────▼────────┐           ┌────────▼───────┐
│  Capacitor iOS │           │ Capacitor      │
│                │           │ Android        │
│  Native APIs:  │           │                │
│  • Camera      │           │ Native APIs:   │
│  • Microphone  │           │ • Camera       │
│  • Push        │           │ • Microphone   │
│  • SQLite      │           │ • Push         │
│  • HealthKit   │           │ • SQLite       │
└────────┬───────┘           └────────┬───────┘
         │                            │
         ▼                            ▼
┌─────────────────┐         ┌─────────────────┐
│   App Store     │         │  Google Play    │
└─────────────────┘         └─────────────────┘
```

---

## 💰 REVENUE FLOW

```
┌────────────────────────────────────────────────────────────┐
│                  BUSINESS MODEL                             │
└────────────────────────────────────────────────────────────┘

ACQUISITION
    │
    ├─► 14-Day Free Trial
    │   └─► No Credit Card Required
    │
CONVERSION (40% target)
    │
    ├─► Choose Plan:
    │   ├─► Solo: $99/mo
    │   ├─► Team: $79/mo/provider
    │   └─► Enterprise: Custom
    │
PAYMENT
    │
    ├─► Stripe Checkout
    │   └─► Subscription Created
    │
USAGE
    │
    ├─► Encounters Logged
    ├─► Usage Metrics Tracked
    └─► Billing Events Recorded
    │
RETENTION
    │
    ├─► Monthly Billing
    ├─► Automatic Renewal
    └─► Churn Monitoring
    │
EXPANSION
    │
    ├─► Add Users
    ├─► Upgrade Tier
    └─► Additional Features

REVENUE CALCULATION
    100 users × $99 = $9,900/mo = $118,800/yr
    500 users × $79 = $39,500/mo = $474,000/yr
    1000 users × $79 = $79,000/mo = $948,000/yr
```

---

## 🚀 DEPLOYMENT PIPELINE

```
┌────────────────────────────────────────────────────────────┐
│              CONTINUOUS DEPLOYMENT                          │
└────────────────────────────────────────────────────────────┘

LOCAL DEVELOPMENT
    │
    ├─► Code Changes
    ├─► npm run dev (Local Test)
    └─► git commit
        │
        ▼
GITHUB
    │
    ├─► Push to main
    ├─► GitHub Actions (CI)
    │   ├─► Run Tests
    │   ├─► Lint Code
    │   └─► Build Assets
    │
    ▼
VERCEL (Auto-Deploy)
    │
    ├─► Build Web App
    ├─► Build Serverless Functions
    ├─► Deploy to Edge Network
    └─► Update scribemd.co
        │
        ▼
PRODUCTION
    │
    ├─► Health Checks
    ├─► Error Monitoring (Sentry)
    ├─► Performance Metrics
    └─► User Analytics
```

---

## 📊 MONITORING DASHBOARD

```
┌────────────────────────────────────────────────────────────┐
│              OBSERVABILITY STACK                            │
└────────────────────────────────────────────────────────────┘

REAL-TIME METRICS
├─► API Response Times
│   └─► Target: <500ms p95
├─► Transcription Latency
│   └─► Target: <100ms
├─► SOAP Generation Time
│   └─► Target: <10s
└─► Error Rates
    └─► Target: <1%

BUSINESS METRICS
├─► Daily Active Users
├─► Encounters Per Day
├─► Revenue (MRR/ARR)
└─► Churn Rate

ALERTS
├─► API Down → Slack
├─► Error Spike → Email
├─► Payment Failed → SMS
└─► Security Event → Phone
```

---

**Reference this diagram when explaining the system to anyone!** 📊
